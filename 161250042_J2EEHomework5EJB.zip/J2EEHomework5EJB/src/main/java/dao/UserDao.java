package dao;

import po.UserPO;

import javax.ejb.Remote;

/**
 * 用户Dao
 * <br>
 * created on 2019/01/04
 *
 * @author 巽
 **/
@Remote
public interface UserDao {
	UserPO getById(String userId);
}
