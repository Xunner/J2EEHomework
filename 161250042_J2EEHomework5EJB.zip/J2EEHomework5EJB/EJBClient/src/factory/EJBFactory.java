package factory;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import java.util.Hashtable;
import java.util.Properties;

/**
 * EJB对象工厂
 * <br>
 * created on 2019/01/14
 *
 * @author 巽
 **/
public class EJBFactory {
	public static Object getEJB(String path) {
		try {
			final Hashtable<String, String> properties = new Hashtable<>();
			properties.put(Context.URL_PKG_PREFIXES, "org.jboss.ejb.client.naming");
			final Context context = new InitialContext(properties);
			return context.lookup(path);

//			Properties jndiProps = new Properties();
//			jndiProps.put(Context.URL_PKG_PREFIXES,"org.jboss.ejb.client.naming");
//			jndiProps.put("jboss.naming.client.ejb.context", true);
//			final Context context = new InitialContext(jndiProps);
//			return context.lookup(path);
		} catch (NamingException e) {
			e.printStackTrace();
		}
		return null;
	}
}
