package po;

import lombok.Data;

import javax.persistence.*;
import java.io.Serializable;

/**
 * 用户对象
 * <br>
 * created on 2019/01/04
 *
 * @author 巽
 **/
@Data
@Entity
@Table(name = "user")
public class UserPO implements Serializable {
	@Id
	@Column(name = "user_id")
	private String userId;
	private String password;

	public UserPO(String userId, String password) {
		this.userId = userId;
		this.password = password;
	}

	public UserPO() {
	}
}
