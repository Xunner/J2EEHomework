package service.impl;

import dao.CommodityDao;
import dao.OrderDao;
import enums.OrderState;
import enums.Result;
import po.CommodityPO;
import po.OrderPO;
import service.OrderService;
import vo.PayVO;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;

/**
 * 订单Service实现类
 * <br>
 * created on 2019/01/06
 *
 * @author 巽
 **/
@Stateless
public class OrderServiceImpl implements OrderService {
	private final static double DISCOUNT_THRESHOLD = 200.0; // 折扣门槛
	private final static double DISCOUNT = 0.7; // 折扣
	@EJB private OrderDao orderDao;
	@EJB private CommodityDao commodityDao;

	@Override
	public PayVO generateOrder(String userId, Map<Integer, Integer> cart) {
		double price = 0.0;
		Map<CommodityPO, Integer> commodities = new HashMap<>();
		for (Integer comId : cart.keySet()) {
			CommodityPO commodity = commodityDao.getById(comId);
			if (commodity == null) return null;
			commodities.put(commodity, cart.get(comId));
			price += commodity.getPrice() * cart.get(comId);
		}
		double actualPayment = price;
		if (price >= DISCOUNT_THRESHOLD) {  // 消费金额高：打折
			actualPayment *= DISCOUNT;
		}
		Result result = orderDao.addOrder(new OrderPO(userId, price, actualPayment, LocalDateTime.now(), OrderState.UNPAID, commodities));
		return new PayVO(result, price, actualPayment);
	}
}
