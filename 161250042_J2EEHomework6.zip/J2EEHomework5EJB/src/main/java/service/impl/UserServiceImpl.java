package service.impl;

import dao.UserDao;
import enums.Result;
import po.UserPO;
import service.UserService;

import javax.ejb.EJB;
import javax.ejb.Stateless;

/**
 * 用户Service实现类
 * <br>
 * created on 2019/01/06
 *
 * @author 巽
 **/
@Stateless
public class UserServiceImpl implements UserService {
	@EJB private UserDao userDao;

	@Override
	public Result logIn(String userId, String password) {
		UserPO userPO = userDao.getById(userId);
		if (userPO != null && userPO.getPassword().equals(password)) {
			return Result.SUCCESS;
		}
		return Result.FAILED;
	}
}
