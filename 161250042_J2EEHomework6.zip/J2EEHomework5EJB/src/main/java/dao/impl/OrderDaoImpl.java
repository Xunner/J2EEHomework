package dao.impl;

import dao.OrderDao;
import enums.Result;
import po.CommodityPO;
import po.OrderPO;

import javax.ejb.Stateless;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

/**
 * no_description
 * <br>
 * created on 2019/01/06
 *
 * @author 巽
 **/
@Stateless
@TransactionManagement(value = TransactionManagementType.BEAN)
public class OrderDaoImpl implements OrderDao {
	@PersistenceContext(unitName="xunner")
	private EntityManager em;
	@Override
	public OrderPO getById(int orderId) {
		return em.find(OrderPO.class, orderId);
	}

	@Override
	@Transactional
	public Result addOrder(OrderPO order) {
		em.persist(order);
		return Result.SUCCESS;
	}
}
