package dao.impl;

import dao.CommodityDao;
import po.CommodityPO;

import javax.ejb.Stateless;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;
import javax.persistence.*;
import java.util.List;

/**
 * 商品Dao实现类
 * <br>
 * created on 2019/01/06
 *
 * @author 巽
 **/
@Stateless
@TransactionManagement(value = TransactionManagementType.BEAN)
public class CommodityDaoImpl implements CommodityDao {
	@PersistenceContext(unitName="xunner")
	private EntityManager em;

	@Override
	public CommodityPO getById(int comId) {
		return em.find(CommodityPO.class, comId);
	}

	@Override
	public List<CommodityPO> getAll() {
		Query query = em.createQuery("from CommodityPO");
		List<CommodityPO> ret = query.getResultList();
		em.clear();
		return ret;
	}
}
