package dao.impl;

import dao.UserDao;
import po.UserPO;

import javax.ejb.Stateless;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 * 用户Dao实现类
 * <br>
 * created on 2019/01/06
 *
 * @author 巽
 **/
@Stateless
@TransactionManagement(value = TransactionManagementType.BEAN)
public class UserDaoImpl implements UserDao {
	@PersistenceContext(unitName="xunner")
	private EntityManager em;

	@Override
	public UserPO getById(String userId) {
		return em.find(UserPO.class, userId);
	}
}
