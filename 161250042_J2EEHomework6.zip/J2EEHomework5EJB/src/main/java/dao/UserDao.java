package dao;

import po.UserPO;

import javax.ejb.Local;

/**
 * 用户Dao
 * <br>
 * created on 2019/01/04
 *
 * @author 巽
 **/
@Local
public interface UserDao {
	UserPO getById(String userId);
}
