# J2EE Homework

> 软院 大三 161250042 胡本霖

### 迭代

- 第6次作业：JPA

### 体系结构

- EJB(Dao+Service) + Client(Servlet) + Vue(Front)
- EJB项目结构：![EJB](img/EJB.png)
- Client项目结构：![Client](img/Client.png)
- 未使用JSP，前后端分离
  - 后端：JBoss+ EJB + JPA(MySQL)
  - 前端：Vue-cli

### 部署

1. 未打包；保留.idea文件夹（或许可以）方便地直接在IDEA上启动项目。

2. 将`jboss-client.jar`文件放至`J2EEHomework5EJB/EJBClient/lib`下，并将其添加为项目依赖。

3. 将项目根目录下的`j2eehomework.sql`文件导入名为"j2eehomework"的MySQL空数据库。

4. 为Jboss服务器安装MySQL驱动。

5. 修改`%JBOSS_HOME%/standalone/configuration/standalone.xml`文件，在`<datasources>`节点中添加如下内容：

   ```xml
   <datasource jndi-name="java:jboss/datasources/MySqlDS" pool-name="MySqlDSPool" enabled="true" jta="true" use-java-context="true" use-ccm="true">
       <connection-url>
           jdbc:mysql://localhost:3306/j2eehomework?characterEncoding=utf8&amp;autoReconnect=true&amp;useSSL=false
       </connection-url>
       <driver>mysql</driver>
       <security>
           <user-name>root</user-name>
           <password>admin</password>
       </security>
   </datasource>
   ```

   再在`<drivers>`节点中添加：

   ```xml
   <driver name="mysql" module="com.mysql">
       <xa-datasource-class>
           com.mysql.jdbc.jdbc2.optional.MysqlXADataSource
       </xa-datasource-class>
   </driver>
   ```

6. 用IDEA导入的JBoss配置启动，或手动将项目部署到JBoss上，再访问`http://localhost:8080/EJBClient_war_exploded/home`。