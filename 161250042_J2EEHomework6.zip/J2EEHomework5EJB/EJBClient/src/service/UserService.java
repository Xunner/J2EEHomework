package service;

import enums.Result;

import javax.ejb.Remote;

/**
 * 用户Service
 * <br>
 * created on 2019/01/06
 *
 * @author 巽
 **/
@Remote
public interface UserService {
	Result logIn(String userId, String password);
}
